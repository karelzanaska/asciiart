package asciiart.image.models.pixel

/**
 * Trait representing a pixel
 */
trait Pixel {


}
